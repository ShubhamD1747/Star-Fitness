<!DOCTYPE html>
<html lang="en">
<head></head>
<style>
body{
    background: black;
}    
.mycss{
	color: rgb(255, 94, 0);
    font-size:40px;
    background: black;
    padding: 10px;
    text-align:center;
}
</style>
<?php session_start(); ?>
<?php
/*
This file contains database configuration assuming you are running mysql using user "root" and password ""
*/


define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'starfitness');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
}
else
{
echo "<h1 class='mycss'>Congratulations!!</h1>";
}
$fname=$lname=$age=$cheight=$cweight=$gweight=$gender=$programname=$email=$pno=$add=$pcode="";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{

$fname = $_POST["rffname"];
$lname = $_POST["rflname"];
$age = $_POST["rfage"];
$cheight = $_POST["rfcheight"];
$cweight = $_POST["rfcweight"];
$gweight = $_POST["rfgweight"];
$gender = $_POST["rfgender"];
$programname = $_POST["rfprogram"];
$email = $_POST["rfemail"];
$pno = $_POST["rfnumber"];
$add = $_POST["rftarea"];
$pcode = $_POST["rfpcode"];
}

if(isset($_SESSION['count'])){
    $_SESSION['count'] +=1;
  }
  else{
    $_SESSION['count'] = 0;
    setcookie('time', time());
  }


$sql = "INSERT INTO rfform (fname,lname,age,cheight,cweight,gweight,gender,programname,email,pno,address,pcode)
VALUES ('$fname','$lname',$age,$cheight,$cweight,$gweight,'$gender','$programname','$email',$pno,'$add',$pcode)";

if ($conn->query($sql) === TRUE)
{
    echo "<h1 class='mycss'>You have successfully registered at Star Fitness on " . date("d-m-Y") .  ".We will contact you shortly.</h1>";
    echo "<h1 class='mycss'>Our first user registered on " .date('d-m-Y', $_COOKIE['time']).  ".This is a huge boost for us.</h1>";
    echo "<h1 class='mycss'><a href='AbtUs.html'>Redirect to home</a></h1>"; 


}
else
{
echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>

</html>