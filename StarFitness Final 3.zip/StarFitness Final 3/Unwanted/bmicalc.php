

<?php
/*
This file contains database configuration assuming you are running mysql using user "root" and password ""
*/
action="./bmicalc.php"

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'Roshan');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
}
else
{
echo "Connected";
}
$name=$age=$weight=$height="";
print_r($_POST);
die;
if ($_SERVER["REQUEST_METHOD"] == "POST")
{

$name = $_POST["bminame"];
$age = $_POST["bmiage"];
$weight = $_POST["bmiweight"];
$height = $_POST["bmiheight"];
}

$sql = "INSERT INTO BMI (Name1, Age1, Weight1,Height1)
VALUES ('$name',$age,$weight,$height)";

if ($conn->query($sql) === TRUE)
{
echo "New record created successfully";
}
else
{
echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>