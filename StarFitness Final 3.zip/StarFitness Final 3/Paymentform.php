
<!DOCTYPE html>
<html lang="en">
<head></head>
<style>
body{
    background: black;
}    
.mycss{
	color: rgb(255, 94, 0);
    font-size:40px;
    background: black;
    padding: 10px;
    text-align:center;
}
</style>
<?php session_start(); ?>
<?php
/*
This file contains database configuration assuming you are running mysql using user "root" and password ""
*/


define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'Roshan');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
}
else
{
    echo "<h1 class='mycss'> Good News!!!  </h1>";
}
$pname=$pcard=$pemail=$padd=$pprogram=$pdate=$pmonth=$pyear=$pgender=$ppay=$pcardno=$pcv=$pexpm=$pexpy=$pamount="";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{

$pname = $_POST["pfname"];
$pcard = $_POST["pfcard"];
$pemail = $_POST["pfemail"];
$padd = $_POST["pfadd"];
$pprogram = $_POST["pfprogram"];
$pdate = $_POST["pfd"];
$pmonth = $_POST["pfm"];
$pyear = $_POST["pfy"];
$pgender = $_POST["pfgender"];
$ppay = $_POST["pfpay"];
$pcardno = $_POST["pfcardno"];
$pcv = $_POST["pfcv"];
$pexpm = $_POST["pfexpm"];
$pexpy = $_POST["pfexpy"];
$pamount = $_POST["pfamount"];

}

if(isset($_SESSION['count'])){
    $_SESSION['count'] +=1;
  }
  else{
    $_SESSION['count'] = 0;
    setcookie('time', time());
  }


$sql = "INSERT INTO Payform (pname,pcard,pemail,padd,pprogram,pdate,pmonth,pyear,pgender,ppay,pcardno,pcv,pexpm,pexpy,pamount)
VALUES ('$pname','$pcard','$pemail','$padd','$pprogram',$pdate,$pmonth,$pyear,'$pgender','$ppay',$pcardno,$pcv,$pexpm,$pexpy,$pamount)";

if ($conn->query($sql) === TRUE)
{
    echo "<h1 class='mycss'>Your payment was succesfull to Star Fitness on " . date("d-m-Y") .  ".Have a great day.</h1>";
    echo "<h1 class='mycss'><a href='Homepage.html'>Redirect to home</a></h1>"; 
    

}
else
{
echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>
</html>