<?php
 include
 $link=mysqli_connect("localhost","root","");
 mysqli_select_db($link,"weight_db");

 $test=array();

 $count=0;
 $res=mysqli_query($link,"select * from weight where user_name='[Shubham]'");
 while($row=mysqli_fetch_array($res))
 {
    $test[$count]["label"]=$row["Label"];
    $test[$count]["y"]=$row["Weight"];
    $count=$count+1;

 }
 
?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "Weight Progress"
	},
	axisX: {
		valueFormatString: "DD MMM"
	},
	axisY: {
		title: "Weight",
		includeZero: true,
		maximum: 70
	},
	data: [{
		type: "splineArea",
		color: "#6599FF",
		xValueType: "dateTime",
		xValueFormatString: "DD MMM",
		yValueFormatString: "#,##0 KGs",
		dataPoints: <?php echo json_encode($test, JSON_NUMERIC_CHECK); ?>
	}]
});
 
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>